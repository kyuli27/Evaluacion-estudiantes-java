/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio;

import java.util.Scanner;

/**
 *
 * @author 50497
 */
public class App {

     
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Nombre del estudiante (o 'salir' para finalizar): ");
            String nombre = scanner.nextLine();

            if (nombre.equals("salir")) {
                break;
            }

            System.out.print("Nota: ");
            int nota = Integer.parseInt(scanner.nextLine());

            if (nota >= 60) {
                System.out.println("Aprobado\n");
            } else {
                System.out.println("Reprobado\n");
            }
        }
    }
}

   

